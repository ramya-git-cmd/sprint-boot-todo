package com.TodoApp.Todo;

import org.springframework.data.repository.CrudRepository;

public interface ListRepository extends CrudRepository<list_data, String> {

}

