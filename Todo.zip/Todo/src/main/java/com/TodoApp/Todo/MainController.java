package com.TodoApp.Todo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(path="/todo")
public class MainController {
    @Autowired
    private ListRepository listRepository;

    @PostMapping(path="/add")
    public @ResponseBody String addTodoList (@RequestParam String user_id
            , @RequestParam String title
            , @RequestParam String description ) {


        list_data n = new list_data();
        n.getUser_id(user_id);
        n.setTitle(title);
        n.setDescription(description);
        listRepository.save(n);
        return "List Created Successfully";
    }

    @GetMapping(path="/all")
    public @ResponseBody Iterable<list_data> getAllList() {
        return ListRepository.findAll();
    }
}